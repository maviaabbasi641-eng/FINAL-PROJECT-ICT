## Project Overview
An online bookstore website where users can browse books,
filter by category, search by title, add books to cart,
and checkout. Built for Air University AICT Project 2026.

## Pages
- Home: Featured books, stats, hero section
- Books: Full catalog with search and filter
- Cart: Add/remove books, view total, checkout
- About: Store info and team members

## Technologies Used
- HTML5
- CSS3
- Bootstrap 5
- JavaScript (Vanilla)
- Git and GitHub

## JavaScript Features
- Add to Cart system
- Remove from Cart
- Checkout with success message
- Filter books by category
- Search books by title
- Stats counter animation
- Navbar scroll effect

