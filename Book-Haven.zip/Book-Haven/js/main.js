// =============================
// CART SYSTEM
// =============================

let cart = JSON.parse(localStorage.getItem('cart')) || [];

// This function runs when "Add to Cart" is clicked
function addToCart(bookName, bookPrice) {

    // Check if book already exists in cart
    let existingItem = cart.find(item => item.name === bookName);

    if (existingItem) {
        // If book already in cart, increase quantity
        existingItem.quantity += 1;
    } else {
        // If new book, add it to cart array
        cart.push({
            name: bookName,
            price: bookPrice,
            quantity: 1
        });
    }

    // Update the cart count badge in navbar
    updateCartCount();

    localStorage.setItem('cart', JSON.stringify(cart));

    // Show confirmation alert
    alert(bookName + " added to cart!");
}

// This function updates the number shown on cart icon
function updateCartCount() {
    let totalItems = 0;
    cart.forEach(function(item) {
        totalItems += item.quantity;
    });

    // Find all elements with id="cart-count" and update them
    let badges = document.querySelectorAll('#cart-count');
    badges.forEach(function(badge) {
        badge.innerHTML = totalItems;
    });
}

// This function displays cart items on cart.html page
function displayCart() {
    let cartContainer = document.getElementById('cartItems');
    let emptyMsg = document.getElementById('emptyMsg');

    // Only run if we are on cart page
    if (!cartContainer) return;

    if (cart.length === 0) {
        // Show empty message
        if (emptyMsg) emptyMsg.style.display = 'block';
        document.getElementById('totalItems').innerHTML = '0';
        document.getElementById('totalPrice').innerHTML = '$0.00';
        return;
    }

    // Hide empty message
    if (emptyMsg) emptyMsg.style.display = 'none';

    // Build HTML for each cart item
    let cartHTML = '';
    let total = 0;
    let totalQty = 0;

    cart.forEach(function(item, index) {
        total += item.price * item.quantity;
        totalQty += item.quantity;

        cartHTML += `
            <div class="cart-item d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-1">${item.name}</h5>
                    <p class="text-muted mb-0">$${item.price} x ${item.quantity}</p>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="book-price">$${(item.price * item.quantity).toFixed(2)}</span>
                    <button class="btn btn-sm btn-outline-danger" onclick="removeFromCart(${index})">Remove</button>
                </div>
            </div>
        `;
    });

    cartContainer.innerHTML = cartHTML + `
        <div class="mt-3 text-center">
            <a href="books.html" class="btn btn-outline-danger">
                Browse More Books
            </a>
        </div>
    `;
    document.getElementById('totalItems').innerHTML = totalQty;
    document.getElementById('totalPrice').innerHTML = '$' + total.toFixed(2);
}

// This function removes an item from cart
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartCount();
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
}

// This function clears the entire cart
function clearCart() {
    cart = [];
    updateCartCount();
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
}

// This function opens the checkout popup
function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty! Add some books first.");
        return;
    }
    // Show the popup
    document.getElementById('checkoutModal').style.display = 'block';
}

// This function closes the popup
function closeCheckout() {
    document.getElementById('checkoutModal').style.display = 'none';
    // Clear the form fields
    document.getElementById('checkoutName').value = '';
    document.getElementById('checkoutEmail').value = '';
    document.getElementById('checkoutPhone').value = '';
}

// This function validates and submits the order
function submitOrder() {
    let name = document.getElementById('checkoutName').value.trim();
    let email = document.getElementById('checkoutEmail').value.trim();
    let phone = document.getElementById('checkoutPhone').value.trim();

    // Hide all errors first
    document.getElementById('nameError').style.display = 'none';
    document.getElementById('emailError').style.display = 'none';
    document.getElementById('phoneError').style.display = 'none';

    // Check if fields are empty
    let hasError = false;

    if (name === '') {
        document.getElementById('nameError').style.display = 'block';
        hasError = true;
    }

    if (email === '' || !email.includes('@')) {
        document.getElementById('emailError').style.display = 'block';
        hasError = true;
    }

    if (phone === '' || phone.length < 11 || isNaN(phone)) {
        document.getElementById('phoneError').style.display = 'block';
        hasError = true;
    }

    // If no errors, place the order
    if (!hasError) {
        // Show success message inside popup
        document.getElementById('orderSuccess').style.display = 'block';

        // Clear the cart
        cart = [];
        updateCartCount();
        localStorage.setItem('cart', JSON.stringify(cart));

        // Close popup after 3 seconds
        setTimeout(function() {
            closeCheckout();
            document.getElementById('orderSuccess').style.display = 'none';
            displayCart();
        }, 3000);
    }
}

// =============================
// FILTER BOOKS BY CATEGORY
// =============================

function filterBooks(category) {
    // Get all book items
    let books = document.querySelectorAll('.book-item');

    // Loop through each book
    books.forEach(function(book) {
        if (category === 'all') {
            // Show all books
            book.style.display = 'block';
        } else {
            // Check if book matches selected category
            if (book.getAttribute('data-category') === category) {
                book.style.display = 'block';
            } else {
                book.style.display = 'none';
            }
        }
    });

    // Update active button style
    let buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach(function(btn) {
        btn.classList.remove('active');
        btn.classList.remove('btn-danger');
        btn.classList.add('btn-outline-danger');
    });

    event.target.classList.add('active');
    event.target.classList.remove('btn-outline-danger');
    event.target.classList.add('btn-danger');
}

// =============================
// SEARCH BOOKS BY NAME
// =============================

let searchInput = document.getElementById('searchInput');
if (searchInput) {
    searchInput.addEventListener('keyup', function() {
        let searchText = this.value.toLowerCase();
        let books = document.querySelectorAll('.book-item');

        books.forEach(function(book) {
            let title = book.querySelector('.card-title').textContent.toLowerCase();
            if (title.includes(searchText)) {
                book.style.display = 'block';
            } else {
                book.style.display = 'none';
            }
        });
    });
}

// =============================
// STATS COUNTER ANIMATION
// =============================

function animateCounter(id, target) {
    let element = document.getElementById(id);
    if (!element) return;

    let count = 0;
    let speed = Math.floor(2000 / target);

    let timer = setInterval(function() {
        count++;
        element.innerHTML = count + '+';
        if (count >= target) {
            clearInterval(timer);
        }
    }, speed);
}

// =============================
// NAVBAR SCROLL EFFECT
// =============================

window.addEventListener('scroll', function() {
    let navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.3)';
    } else {
        navbar.style.boxShadow = 'none';
    }
});

// =============================
// RUN WHEN PAGE LOADS
// =============================

window.addEventListener('load', function() {
    // Start counter animation on home page
    animateCounter('stat1', 500);
    animateCounter('stat2', 1200);
    animateCounter('stat3', 6);
    animateCounter('stat4', 350);

    // Display cart if on cart page
    displayCart();

    // Update cart count on all pages
    updateCartCount();
});